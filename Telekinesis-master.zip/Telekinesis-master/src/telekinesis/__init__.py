from .route import app as Telekinesis
from .methods import initialize
